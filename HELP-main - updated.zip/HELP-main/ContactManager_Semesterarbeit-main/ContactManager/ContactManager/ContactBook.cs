﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ContactManager
{
    public class ContactBook
    {
        public int EmployeeCounter { get; set; }
        
        //List of all employees, including trainees
        public Dictionary<int, Employee> Employees { get; set; }

        //List of all customers
        public Dictionary<int, Customer> Customers { get; set; }

        //List of all contact documentations
        public Dictionary<int, ContactDoc> ContactDocs { get; set; }

        //has Lists for changes on employees, customers and contact documentation in it (as strings)
        //not sure if this makes sense.. see as well History.cs (maybe it makes more sense to collect History elements?)
        public History History { get; set; }

        public ContactBook()
        {
            Employees = new Dictionary<int, Employee>();
            Customers = new Dictionary<int, Customer>();
            ContactDocs = new Dictionary<int, ContactDoc>();

            EmployeeTable = new DataTable();
            DefineEmployeeTable();

            EmployeeCounter = 0;

            ContactDocTable = new DataTable();
            DefineContactDocTable();

            History = new History();
        }


        //Table includes Trainees
        public DataTable EmployeeTable { get; set; }

        public DataTable CustomerTable { get; set; }

        public DataTable ContactDocTable { get; set; }

        private void DefineEmployeeTable()
        {
            EmployeeTable.Columns.Add("EmployeeNumber", typeof(Int32));             //0
            EmployeeTable.Columns.Add("Salutation", typeof(String));                //1
            EmployeeTable.Columns.Add("Firstname", typeof(String));                 //2
            EmployeeTable.Columns.Add("Lastname", typeof(String));                  //3
            EmployeeTable.Columns.Add("Birthday", typeof(DateTime));                //4
            EmployeeTable.Columns.Add("Gender", typeof(String));                    //5
            EmployeeTable.Columns.Add("Mobile Number", typeof(String));             //6
            EmployeeTable.Columns.Add("eMail", typeof(String));                     //7
            EmployeeTable.Columns.Add("Status", typeof(String));                    //8
            EmployeeTable.Columns.Add("AHV Number", typeof(String));                //9
            EmployeeTable.Columns.Add("Location", typeof(String));                  //10
            EmployeeTable.Columns.Add("Nationality", typeof(String));               //11
            EmployeeTable.Columns.Add("Adress", typeof(String));                    //12
            EmployeeTable.Columns.Add("Zip Code", typeof(String));                  //13
            EmployeeTable.Columns.Add("Phone Number Privat", typeof(String));       //14
            EmployeeTable.Columns.Add("Phone Number Business", typeof(String));     //15
            EmployeeTable.Columns.Add("Fax Number", typeof(String));                //16
            EmployeeTable.Columns.Add("Titel", typeof(String));                     //17
            EmployeeTable.Columns.Add("Division", typeof(String));                  //18
            EmployeeTable.Columns.Add("Date of Entry", typeof(DateTime));           //19
            EmployeeTable.Columns.Add("Date of Exit", typeof(DateTime));            //20
            EmployeeTable.Columns.Add("Employeement Level", typeof(String));        //21
            EmployeeTable.Columns.Add("Role", typeof(String));                      //22
            EmployeeTable.Columns.Add("Cadre Level", typeof(String));               //23
            EmployeeTable.Columns.Add("Max Trainee Years", typeof(String));         //24
            EmployeeTable.Columns.Add("Current Traine Year", typeof(String));       //25
        }

        private void DefineCustomerTable()
        {
            CustomerTable.Columns.Add("Customer Number", typeof(Int32));
            CustomerTable.Columns.Add("Salutation", typeof(String));
            CustomerTable.Columns.Add("Firstname", typeof(String));
            CustomerTable.Columns.Add("Lastname", typeof(String));
            CustomerTable.Columns.Add("Birthday", typeof(DateTime));
            CustomerTable.Columns.Add("Gender", typeof(String));
            CustomerTable.Columns.Add("Mobile Number", typeof(String));
            CustomerTable.Columns.Add("eMail", typeof(String));
            CustomerTable.Columns.Add("Status", typeof(String));
            CustomerTable.Columns.Add("AHV Number", typeof(String));
            CustomerTable.Columns.Add("Location", typeof(String));
            CustomerTable.Columns.Add("Nationality", typeof(String));
            CustomerTable.Columns.Add("Adress", typeof(String));
            CustomerTable.Columns.Add("Zip Code", typeof(String));
            CustomerTable.Columns.Add("Phone Number Privat", typeof(String));
            CustomerTable.Columns.Add("Company", typeof(String));
            CustomerTable.Columns.Add("Business-Adress", typeof(String));
            CustomerTable.Columns.Add("Customer Type", typeof(String));
            CustomerTable.Columns.Add("Customer Contact", typeof(String));
        }

        public void FillEmployeeTable()
        {
            foreach (KeyValuePair<int, Employee> employeePair in Employees)
            {
                EmployeeTable.Rows.Add(employeePair.Value.GetDataRow(EmployeeTable));
                EmployeeCounter++;
            }
        }

        private void DefineContactDocTable()
        {
            ContactDocTable = new DataTable();
            ContactDocTable.Columns.Add("ID", typeof(Guid));
            ContactDocTable.Columns.Add("Kunde", typeof(string));
            ContactDocTable.Columns.Add("Mitarbeiter", typeof(string));
            ContactDocTable.Columns.Add("Datum", typeof(DateTime));
            ContactDocTable.Columns.Add("Zeit", typeof(string));
            ContactDocTable.Columns.Add("Notizen", typeof(string));
            ContactDocTable.Columns.Add("edit", typeof(byte[]));
            ContactDocTable.Columns.Add("save", typeof(byte[]));
            ContactDocTable.Columns.Add("delete", typeof(byte[]));
        }

        public void FillContactDocTable()
        {
            foreach (KeyValuePair<int, ContactDoc> contactDocPair in ContactDocs)
            {
                ContactDocTable.Rows.Add(contactDocPair.Value.GetDataRow(ContactDocTable));
            }
        }

        //Loads the initial data from the disk
        public List<ContactDoc> GetContactDocInitialData()
        {
            var listContactDocs = new List<ContactDoc>();

            //todo: variablen übergeben anstatt leer constructor
            ContactDoc contactDoc = new ContactDoc();
            contactDoc.Id = Guid.NewGuid();
            contactDoc.Mitarbeiter = new Employee("Herr", "Steffen", "Eisenberg", "steffen.eisenberg@gmail.com", new DateTime(1994, 3, 2), 1, new DateTime(2015, 1, 3), new DateTime(1980, 1, 1), "100%");
            contactDoc.Kunde = new Customer("Herr", "Alexander", "Himmel", "alexander.himmel@gmail.com", new DateTime(1997, 7, 18), 1, "Habicht AG");
            contactDoc.Notes = "notest askldfjasldkfjasdkfjaskdf";
            contactDoc.Datum = DateTime.Now.Date;
            contactDoc.Zeit = DateTime.Now.ToString("HH:mm");
            listContactDocs.Add(contactDoc);

            ContactDoc contactDoc2 = new ContactDoc();
            contactDoc2.Id = Guid.NewGuid();
            contactDoc2.Mitarbeiter = new Employee("Herr", "Swen", "Zimmermann", "swen.zimmermann@gmail.com", new DateTime(1996, 5, 7), 2, new DateTime(2013, 4, 21), new DateTime(1980, 1, 1), "100%");
            contactDoc2.Kunde = new Customer("Frau", "Schulze", "Lena", "lena.schulze@gmail.com", new DateTime(1987, 5, 13), 2, "Kugel GmbH");
            contactDoc2.Notes = "notest askldfjasldkfjasdkfjaskdf";
            contactDoc2.Datum = DateTime.Now.Date;
            contactDoc2.Zeit = DateTime.Now.ToString("HH:mm");
            listContactDocs.Add(contactDoc2);

            ContactDoc contactDoc3 = new ContactDoc();
            contactDoc3.Id = Guid.NewGuid();
            contactDoc3.Mitarbeiter = new Employee("Frau", "Juliane", "Baier", "juliane.baier@gmail.com", new DateTime(1987, 3, 12), 3, new DateTime(2018, 3, 12), new DateTime(1980, 1, 1), "80%");
            contactDoc3.Kunde = new Customer("Frau", "Katrin", "Herz", "katrin.herz@gmail.com", new DateTime(2000, 9, 27), 3, "Schluckspecht Inc.");
            contactDoc3.Notes = "notest askldfjasldkfjasdkfjaskdf";
            contactDoc3.Datum = DateTime.Now.Date;
            contactDoc3.Zeit = DateTime.Now.ToString("HH:mm");
            listContactDocs.Add(contactDoc3);

            return listContactDocs;
        }
    
        //TestData while Loading is not implemented yet
        public ContactBook GetContactBookInitialData()
        {
            ContactBook testContactBook = new ContactBook();

            testContactBook.Employees[1] = new Employee("Herr", "Steffen", "Eisenberg", "steffen.eisenberg@gmail.com", new DateTime(1994, 3, 2), 1, new DateTime(2015, 1, 3), new DateTime(1980, 1, 1), "100%");
            testContactBook.Employees[2] = new Employee("Herr", "Swen", "Zimmermann", "swen.zimmermann@gmail.com", new DateTime(1996, 5, 7), 2, new DateTime(2013, 4, 21), new DateTime(1980, 1, 1), "100%");
            testContactBook.Employees[3] = new Employee("Frau", "Juliane", "Baier", "juliane.baier@gmail.com", new DateTime(1987, 3, 12), 3, new DateTime(2018, 3, 12), new DateTime(1980, 1, 1), "80%");

            testContactBook.Employees[4] = new Trainee("Frau", "Antje", "Lang", "antje.lang@gmail.com", new DateTime(2003, 4, 17), 4, new DateTime(2019, 8, 1), new DateTime(1980, 1, 1), "100%", 4, 2);
            testContactBook.Employees[5] = new Trainee("Herr", "Stefan", "Keller", "stefan.keller@gmail.com", new DateTime(2002, 12, 3), 5, new DateTime(2018, 8, 2), new DateTime(1980, 1, 1), "100%", 3, 3);

            testContactBook.Employees[6] = new Employee("Frau", "Franziska", "Schweitzer", "franziska.schweitzer@gmail.com", new DateTime(1963, 11, 11), 6, new DateTime(2012, 1, 1), new DateTime(1980, 1, 1), "60%", "weiblich",
                "0786003020", "aktiv", "723.457.3756.30", "St. Gallen", "CH", "Sieberstrasse 13", "9000", "0764001040", "Hoheit", "0717274050", "0717274000", "R&D", "Head of R&D", 4);

            testContactBook.Employees[7] = new Trainee("Frau", "Mandy", "Roth", "mandy.roth@gmail.com", new DateTime(2001, 12, 1), 7, new DateTime(2019, 5, 1), new DateTime(1980, 1, 1), "100%", 4, 2, "weiblich",
                "0786003121", "aktiv", "732.467.3876.31", "Balgach", "CH", "Segerstrasse 16", "9436", "0764103069", "Stift", "0717274156", "0717274000", "Fertigung", "Lehrling CNC Fräsen", 0);

            testContactBook.Employees[8] = new Employee(8);

            testContactBook.Customers[1] = new Customer("Herr", "Alexander", "Himmel", "alexander.himmel@gmail.com", new DateTime(1997, 7, 18), 1, "Habicht AG");
            testContactBook.Customers[2] = new Customer("Frau", "Schulze", "Lena", "lena.schulze@gmail.com", new DateTime(1987, 5, 13), 2, "Kugel GmbH");
            testContactBook.Customers[3] = new Customer("Frau", "Katrin", "Herz", "katrin.herz@gmail.com", new DateTime(2000, 9, 27), 3, "Schluckspecht Inc.");

            testContactBook.Customers[4] = new Customer("Herr", "Jörg", "Reinhardt", "joerg.reinhardt@gmail.com", new DateTime(1988, 7, 16), 4, "Nutten AG", "männlich", "0795001245", "aktiv", "741.587.4126.80", "Zürich", "DE",
                "Schelmstrasse 3", "6000", "0717405060", "Hoheitstrasse 60", "Bester Kunde", "KundenKontakt");

            return testContactBook;
        }
    }
}
