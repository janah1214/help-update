﻿
namespace ContactManager
{
    partial class Form_ContactDoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_ContactDoc));
      this.PbBackToDashboard = new System.Windows.Forms.PictureBox();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.TxtSearchDB = new System.Windows.Forms.TextBox();
      this.LblDashboard = new System.Windows.Forms.Label();
      this.ContactGridview = new System.Windows.Forms.DataGridView();
      this.CmdCreateEmployee = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.PbBackToDashboard)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.ContactGridview)).BeginInit();
      this.SuspendLayout();
      // 
      // PbBackToDashboard
      // 
      this.PbBackToDashboard.BackColor = System.Drawing.Color.Transparent;
      this.PbBackToDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.PbBackToDashboard.Image = global::ContactManager.Properties.Resources.Dashboard;
      this.PbBackToDashboard.Location = new System.Drawing.Point(55, 69);
      this.PbBackToDashboard.Margin = new System.Windows.Forms.Padding(4);
      this.PbBackToDashboard.Name = "PbBackToDashboard";
      this.PbBackToDashboard.Size = new System.Drawing.Size(103, 79);
      this.PbBackToDashboard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
      this.PbBackToDashboard.TabIndex = 15;
      this.PbBackToDashboard.TabStop = false;
      this.PbBackToDashboard.Click += new System.EventHandler(this.PbBackToDashboard_Click_1);
      // 
      // pictureBox1
      // 
      this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
      this.pictureBox1.Location = new System.Drawing.Point(0, 0);
      this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(1924, 1055);
      this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.pictureBox1.TabIndex = 10;
      this.pictureBox1.TabStop = false;
      // 
      // TxtSearchDB
      // 
      this.TxtSearchDB.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Bold);
      this.TxtSearchDB.Location = new System.Drawing.Point(484, 95);
      this.TxtSearchDB.Margin = new System.Windows.Forms.Padding(9, 7, 9, 7);
      this.TxtSearchDB.Name = "TxtSearchDB";
      this.TxtSearchDB.Size = new System.Drawing.Size(961, 39);
      this.TxtSearchDB.TabIndex = 18;
      // 
      // LblDashboard
      // 
      this.LblDashboard.AutoSize = true;
      this.LblDashboard.BackColor = System.Drawing.Color.Transparent;
      this.LblDashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.LblDashboard.ForeColor = System.Drawing.Color.White;
      this.LblDashboard.Location = new System.Drawing.Point(27, 146);
      this.LblDashboard.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
      this.LblDashboard.Name = "LblDashboard";
      this.LblDashboard.Size = new System.Drawing.Size(184, 39);
      this.LblDashboard.TabIndex = 19;
      this.LblDashboard.Text = "Dashboard";
      this.LblDashboard.UseMnemonic = false;
      // 
      // ContactGridview
      // 
      this.ContactGridview.AllowUserToAddRows = false;
      this.ContactGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.ContactGridview.Location = new System.Drawing.Point(364, 398);
      this.ContactGridview.Margin = new System.Windows.Forms.Padding(4);
      this.ContactGridview.Name = "ContactGridview";
      this.ContactGridview.RowHeadersWidth = 51;
      this.ContactGridview.Size = new System.Drawing.Size(1410, 514);
      this.ContactGridview.TabIndex = 20;
      // 
      // CmdCreateEmployee
      // 
      this.CmdCreateEmployee.Location = new System.Drawing.Point(364, 346);
      this.CmdCreateEmployee.Margin = new System.Windows.Forms.Padding(4);
      this.CmdCreateEmployee.Name = "CmdCreateEmployee";
      this.CmdCreateEmployee.Size = new System.Drawing.Size(160, 28);
      this.CmdCreateEmployee.TabIndex = 23;
      this.CmdCreateEmployee.Text = "Add New ContactDoc";
      this.CmdCreateEmployee.UseVisualStyleBackColor = true;
      this.CmdCreateEmployee.Click += new System.EventHandler(this.CmdCreateEmployee_Click);
      // 
      // Form_ContactDoc
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoSize = true;
      this.ClientSize = new System.Drawing.Size(1924, 1055);
      this.Controls.Add(this.CmdCreateEmployee);
      this.Controls.Add(this.ContactGridview);
      this.Controls.Add(this.LblDashboard);
      this.Controls.Add(this.TxtSearchDB);
      this.Controls.Add(this.PbBackToDashboard);
      this.Controls.Add(this.pictureBox1);
      this.Margin = new System.Windows.Forms.Padding(4);
      this.Name = "Form_ContactDoc";
      this.Text = "Form_ContactDoc";
      this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
      this.Load += new System.EventHandler(this.Form_ContactDoc_Load);
      ((System.ComponentModel.ISupportInitialize)(this.PbBackToDashboard)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.ContactGridview)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox PbBackToDashboard;
        private System.Windows.Forms.TextBox TxtSearchDB;
        private System.Windows.Forms.Label LblDashboard;
        private System.Windows.Forms.DataGridView ContactGridview;
    private System.Windows.Forms.Button CmdCreateEmployee;
  }
}