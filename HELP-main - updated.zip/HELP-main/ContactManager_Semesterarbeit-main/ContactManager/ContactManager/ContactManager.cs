﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManager
{
    public class ContactManager
    {
        public ContactBook contactBook { get; set; }

        public void StartUp()
        {
            //Need Testdata
            /*
            Disk disk = new Disk();
            contactBook = disk.Load();
            */
        }

    }
}
