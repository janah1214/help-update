﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactManager
{
    public partial class Form_ContactDoc : Form
    {
        private ContactBook contactBook;
        private Form_Dashboard form_Dashboard;

        public Form_ContactDoc(ContactBook contactBook, Form_Dashboard frm_Dashboard)
        {
            InitializeComponent();
            this.contactBook = contactBook;
            this.form_Dashboard = frm_Dashboard;
        }


        // Dashboard-Icon-Hintergrund Transparent setzen
        private void Form_ContactDoc_Load(object sender, EventArgs e)
        {
            PbBackToDashboard.Parent = pictureBox1;
            PbBackToDashboard.BackColor = Color.Transparent;

            LblDashboard.Parent = pictureBox1;
            LblDashboard.BackColor = Color.Transparent;

            // Stammdaten speichern
            var listContactDocs = this.contactBook.GetContactDocInitialData(); //todo: Disk.Load() aufrufen statt so
            this.contactBook.FillContactDocTable();
            Disk.Save(this.contactBook);

            foreach (var conDoc in listContactDocs)
            {
              var imageConverter = new ImageConverter();
              var editIcon = (byte[])imageConverter.ConvertTo(Properties.Resources.Edit, typeof(byte[]));
              var saveIcon = (byte[])imageConverter.ConvertTo(Properties.Resources.Save, typeof(byte[])); //todo
              var deleteIcon = (byte[])imageConverter.ConvertTo(Properties.Resources.Delete, typeof(byte[])); //todo

              contactBook.ContactDocTable.Rows.Add
                (
                conDoc.Id = Guid.NewGuid(),
                conDoc.Kunde.Vorname + " " + conDoc.Kunde.Nachname,
                conDoc.Mitarbeiter.Vorname + " " + conDoc.Mitarbeiter.Nachname,
                conDoc.Datum,
                conDoc.Zeit,
                conDoc.Notes,
                editIcon,
                saveIcon,
                deleteIcon
                );
            }
      
            ContactGridview.DataSource = contactBook.ContactDocTable;

            //save to disk
            Disk.Save(listContactDocs);
        }


        // Anhand mit einem Klick auf Dashboard-Icon zurück zum Dashboard gelangen
        private void PbBackToDashboard_Click_1(object sender, EventArgs e)
        {
            form_Dashboard.Show();
            this.Close();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            form_Dashboard.Show();
            base.OnFormClosing(e);
        }

    private void CmdCreateEmployee_Click(object sender, EventArgs e)
    {
      contactBook.EmployeeTable.Rows.Add();
    }
  }
}
