﻿namespace ContactManager
{
    public class Dictionary<T>
    {
    }
}