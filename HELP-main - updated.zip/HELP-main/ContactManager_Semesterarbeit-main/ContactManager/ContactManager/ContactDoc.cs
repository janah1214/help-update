﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactManager
{
    public class ContactDoc
    {
        public Guid Id { get; set; }

        public Customer Kunde { get; set; }

        public Employee Mitarbeiter { get; set; }

        public DateTime Datum { get; set; }

        public string Zeit { get; set; }

        public string Notes { get; set; }

        //constructor
        public ContactDoc(Customer customer, Employee employee, string notes, DateTime date)
        {
          Id = Guid.NewGuid();
          Kunde = customer;
          Mitarbeiter = employee;
          Notes = notes;
          Datum = date;
          Zeit = date.ToString("HH:mm");
        }

        public ContactDoc() { }

        public DataRow GetDataRow(DataTable table)
        {
            DataRow row = table.NewRow();

            row[0] = this.Id;
            row[1] = this.Kunde;
            row[2] = this.Mitarbeiter;
            row[3] = this.Datum;
            row[4] = this.Zeit;
            row[5] = this.Notes;

            return row;
        }

        public ContactDoc JoinData()
        {
            return null;
        }

        //Updating information saved in the object
        public void Update()
        {

        }

  }
}
